#include <stdio.h>
#include<windows.h>
#include<string.h>
#include <math.h>
#include <GL/glut.h>
#include<iostream>
using namespace std;



float translate_x = 0.0; float translate_y = 0.0; float translate_z = -30.0;

float copy1X1 = 25,
copy1Y1 = 20,
copy1X2 = 25,
copy1Y2 = 30,
copy1X3 = 20,
copy1Y3 = 25;

float rCopy1X1,
rCopy1Y1,
rCopy1X2,
rCopy1Y2,
rCopy1X3,
rCopy1Y3;

float copy2X1 = 25,
copy2Y1 = 3,
copy2X2 = 25,
copy2Y2 = -7,
copy2X3 = 30,
copy2Y3 = -2;

float rCopy2X1,
rCopy2Y1,
rCopy2X2,
rCopy2Y2,
rCopy2X3,
rCopy2Y3;

float copy3X1 = 30,
copy3Y1 = -25,
copy3X2 = 20,
copy3Y2 = -25,
copy3X3 = 25,
copy3Y3 = -30;

float rCopy3X1,
rCopy3Y1,
rCopy3X2,
rCopy3Y2,
rCopy3X3,
rCopy3Y3;

int point = 0;
char  a[15];

GLfloat UpwardsScrollVelocity = -10.0;
float view = 10.0;


void reshape2(int w, int h)
{
	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(60, 1.0, 1.0, 3200);
	glMatrixMode(GL_MODELVIEW);
}

char quote[6][80];
int numberOfQuotes = 0, i;


void timeTick(void)
{
	if (UpwardsScrollVelocity< -600)
		view -= 0.000011;
	if (view < 0) { view = 20; UpwardsScrollVelocity = -10.0; }
	//  exit(0);
	UpwardsScrollVelocity -= 0.1;
	glutPostRedisplay();

}

void RenderToDisplay()
{
	int l, lenghOfQuote, i;
	
	glTranslatef(0.0, -100, UpwardsScrollVelocity);
	glRotatef(-20, 1.0, 0.0, 0.0);
	glScalef(0.1, 0.1, 0.1);



	for (l = 0; l<numberOfQuotes; l++)
	{
		lenghOfQuote = (int)strlen(quote[l]);
		glPushMatrix();
		glTranslatef(-(lenghOfQuote * 37), -(l * 200), 0.0);
		for (i = 0; i < lenghOfQuote; i++)
		{
			glColor3f((UpwardsScrollVelocity / 10) + 300 + (l * 10), (UpwardsScrollVelocity / 10) + 300 + (l * 10), 0.0);
			glutStrokeCharacter(GLUT_STROKE_ROMAN, quote[l][i]);

			
		}
		
		
		glPopMatrix();
	}

}

void myDisplayFunction(void)
{
	glClear(GL_COLOR_BUFFER_BIT);
	glLoadIdentity();
	gluLookAt(0.0, 30.0, 100.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
	RenderToDisplay();
	glutSwapBuffers();
}


void init()
{
	glClearColor(1.0, 1.0, 1.0, 0.0);
	glColor3f(0.0f, 0.0f, 0.0f);
	glPointSize(4.0);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0.0, 1024, 0.0, 768);
}



void Triangle1(void)
{
	glColor3f(0.0, 0.0, 1.0);

	glBegin(GL_TRIANGLES);

	glVertex2d(-30, 25);
	glVertex2d(-20, 25);
	glVertex2d(-25, 30);
}

void Triangle2(void)
{
	glColor3f(0.0, 0.0, 1.0);

	glBegin(GL_TRIANGLES);

	glVertex2d(-30, -2);
	glVertex2d(-20, -2);
	glVertex2d(-25, 3);
}


void Triangle3(void)
{
	glColor3f(0.0, 0.0, 1.0);

	glBegin(GL_TRIANGLES);

	glVertex2d(-30, -25);
	glVertex2d(-20, -25);
	glVertex2d(-25, -20);
}



void TriangleCopy1(void)
{

	glColor3f(0.0, 1.0, 1.0);

	glBegin(GL_TRIANGLES);

	glVertex2d(copy1X1, copy1Y1);
	glVertex2d(copy1X2, copy1Y2);
	glVertex2d(copy1X3, copy1Y3);
}

void TriangleCopy2(void)
{
	glColor3f(0.0, 1.0, 1.0);

	glBegin(GL_TRIANGLES);

	glVertex2d(copy2X1, copy2Y1);
	glVertex2d(copy2X2, copy2Y2);
	glVertex2d(copy2X3, copy2Y3);
}

void TriangleCopy3(void)
{
	glColor3f(0.0, 1.0, 1.0);

	glBegin(GL_TRIANGLES);

	glVertex2d(copy3X1, copy3Y1);
	glVertex2d(copy3X2, copy3Y2);
	glVertex2d(copy3X3, copy3Y3);
}


void rotate1(void)
{
	copy1X1 = copy1X1 - 25,
		copy1Y1 = copy1Y1 - 25,
		copy1X2 = copy1X2 - 25,
		copy1Y2 = copy1Y2 - 25,
		copy1X3 = copy1X3 - 25,
		copy1Y3 = copy1Y3 - 25;

	rCopy1X1 = -copy1Y1;
	rCopy1Y1 = copy1X1;
	rCopy1X2 = -copy1Y2;
	rCopy1Y2 = copy1X2;
	rCopy1X3 = -copy1Y3;
	rCopy1Y3 = copy1X3;

	copy1X1 = rCopy1X1 + 25;
	copy1Y1 = rCopy1Y1 + 25;
	copy1X2 = rCopy1X2 + 25;
	copy1Y2 = rCopy1Y2 + 25;
	copy1X3 = rCopy1X3 + 25;
	copy1Y3 = rCopy1Y3 + 25;

	
}

void rotate2(void)
{
	copy2X1 = copy2X1 - 25,
		copy2Y1 = copy2Y1 +2,
		copy2X2 = copy2X2 -25,
		copy2Y2 = copy2Y2 +2,
		copy2X3 = copy2X3 - 25,
		copy2Y3 = copy2Y3 +2;

	rCopy2X1 = -copy2Y1;
	rCopy2Y1 = copy2X1;
	rCopy2X2 = -copy2Y2;
	rCopy2Y2 = copy2X2;
	rCopy2X3 = -copy2Y3;
	rCopy2Y3 = copy2X3;

	copy2X1 = rCopy2X1 + 25;
	copy2Y1 = rCopy2Y1 -2;
	copy2X2 = rCopy2X2 + 25;
	copy2Y2 = rCopy2Y2 -2;
	copy2X3 = rCopy2X3 + 25;
	copy2Y3 = rCopy2Y3 -2;

	

}

void rotate3(void)
{
	copy3X1 = copy3X1 - 25,
		copy3Y1 = copy3Y1 + 25,
		copy3X2 = copy3X2 - 25,
		copy3Y2 = copy3Y2 + 25,
		copy3X3 = copy3X3 - 25,
		copy3Y3 = copy3Y3 + 25;

	rCopy3X1 = -copy3Y1;
	rCopy3Y1 = copy3X1;
	rCopy3X2 = -copy3Y2;
	rCopy3Y2 = copy3X2;
	rCopy3X3 = -copy3Y3;
	rCopy3Y3 = copy3X3;

	copy3X1 = rCopy3X1 + 25;
	copy3Y1 = rCopy3Y1 - 25;
	copy3X2 = rCopy3X2 + 25;
	copy3Y2 = rCopy3Y2 - 25;
	copy3X3 = rCopy3X3 + 25;
	copy3Y3 = rCopy3Y3 - 25;

	
}

	


void reshape(int w, int h) {
	glViewport(0, 0, (GLsizei)w, (GLsizei)h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(100.0f, (GLfloat)w / (GLfloat)h, 1.0f, 100.0f);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

void myDisplay()
{

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();
	glTranslatef(translate_x, translate_y, translate_z);


	Triangle1();
	Triangle2();
	Triangle3();

	TriangleCopy1();
	TriangleCopy2();
	TriangleCopy3();

	glEnd();
	glFlush();

	glutSwapBuffers();



}

void restart(void)
{
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowPosition(0, 0);
	glutInitWindowSize(1024, 768);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();
	glTranslatef(translate_x, translate_y, translate_z);
	glutPostRedisplay();
	copy1X1 = 25,
		copy1Y1 = 20,
		copy1X2 = 25,
		copy1Y2 = 30,
		copy1X3 = 20,
		copy1Y3 = 25;


	copy2X1 = 25,
		copy2Y1 = 3,
		copy2X2 = 25,
		copy2Y2 = -7,
		copy2X3 = 30,
		copy2Y3 = -2;


	copy3X1 = 30,
		copy3Y1 = -25,
		copy3X2 = 20,
		copy3Y2 = -25,
		copy3X3 = 25,
		copy3Y3 = -30;




	glutDisplayFunc(myDisplay);
	init();
	reshape(1024, 768);
	glutMainLoop();



}


void gameLost(void)
{
	a[15] = (char)point;
	strcpy_s(quote[0], "Game Over");

	//strcpy_s(quote[1], "Winner Is ");
	//	strcpy_s(quote[2], );
	strcpy_s(quote[1], "Point is:");
	strcpy_s(quote[2], &a[15]);
	numberOfQuotes = 3;

	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	//glutInitWindowSize(1360, 750);
	glutCreateWindow("Game Result");
	glClearColor(0.0, 0.0, 0.0, 1.0);
	glLineWidth(3);

	glutDisplayFunc(myDisplayFunction);
	glutReshapeFunc(reshape2);
	glutIdleFunc(timeTick);
	glutMainLoop();

}


void translate(void)
{
	
		copy1X1 = copy1X1 - 50;
		copy1Y1 = copy1Y1;
		copy1X2 = copy1X2 - 50;
		copy1Y2 = copy1Y2;
		copy1X3 = copy1X3 - 50;
		copy1Y3 = copy1Y3;
		
	
		copy2X1 = copy2X1 - 50;
		copy2Y1 = copy2Y1;
		copy2X2 = copy2X2 - 50;
		copy2Y2 = copy2Y2;
		copy2X3 = copy2X3 - 50;
		copy2Y3 = copy2Y3;
		
	

	
		copy3X1 = copy3X1 - 50;
		copy3Y1 = copy3Y1;
		copy3X2 = copy3X2 - 50;
		copy3Y2 = copy3Y2;
		copy3X3 = copy3X3 - 50;
		copy3Y3 = copy3Y3;
		
	

	//glFlush();
	if (copy1X1 == -30 && copy1Y1 == 25 && copy1X2 == -20 && copy1Y2 == 25 && copy1X3 == -25 && copy1Y3 == 30)
	{
		if (copy2X1 == -30 && copy2Y1 == -2 && copy2X2 == -20 && copy2Y2 == -2 && copy2X3 == -25 && copy2Y3 == 3)
		{
			if (copy3X1 == -30 && copy3Y1 == -25 && copy3X2 == -20 && copy3Y2 == -25 && copy3X3 == -25 && copy3Y3 == -20)
			{
				cout << "Mathced" << endl;
				point = point + 1;
				cout << "Point :" << point << endl;
				restart();

							}

			else
			{
				gameLost();
			}

		}

		else
		{
			gameLost();
		}


	}

	else
	{
		//cout << "LOSS"<<endl;
		//glutPostRedisplay();
		gameLost();
//		return 0;

	}

}

void keyboard(int key, int x, int y)
{ 
	switch (key)
	{
	case GLUT_KEY_LEFT:
		rotate1();
		glutPostRedisplay();
		break;
	case GLUT_KEY_DOWN:
		rotate2();
		glutPostRedisplay();
		break;
	case GLUT_KEY_RIGHT:
		rotate3();
		glutPostRedisplay();
		break;

	case GLUT_KEY_UP:
		translate();
		
		break;
	default:
		break;
	}
}

int main(int argc, char** argv){
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowPosition(0, 0);
	glutInitWindowSize(1024, 768);
	glutCreateWindow("Matching Shape");

	glutDisplayFunc(myDisplay);
	glutSpecialFunc(keyboard);

	init();
	reshape(1024, 768);
	glutMainLoop();

}
